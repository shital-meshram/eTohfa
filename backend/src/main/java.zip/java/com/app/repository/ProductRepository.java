package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojo.Products;

public interface ProductRepository extends JpaRepository<Products, Integer>{

}
