package com.app.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.pojo.Categories;
import com.app.pojo.Products;
import com.app.repository.ProductRepository;


@Service
@Transactional
public class ProductServiceImpl implements IProductService{

	@Autowired
	private ProductRepository proRepo;
	
	@Override
	public List<Products> getAllProduct() {
		return proRepo.findAll();
	}

	@Override
	public Products AddNewProducts(Products transientPOJO) {
		Categories categ = new Categories();
		categ.setCatName(transientPOJO.getCategory().getCatName());
		categ.setBrand(transientPOJO.getCategory().getBrand());
		
		Products newProd =  new Products();
		newProd.setProdName(transientPOJO.getProdName());
		   newProd.setDescription(transientPOJO.getDescription());
		   newProd.setPrice(transientPOJO.getPrice());
		   newProd.setImgUrl(transientPOJO.getImgUrl());
		   newProd.setQuantity(transientPOJO.getQuantity());
		   newProd.setCategory(categ);
		   
		   proRepo.save(newProd);
		   return newProd;
		
	}

	@Override
	public Optional<Products> getProductsById(int id) {
		return proRepo.findById(id);
	}

	@Override
	public Products updateProductDetails(int productId, Products detachedPOJO) {
		Optional<Products>p=proRepo.findById(productId);
		if(p!=null)
		{
			Products p1=p.get();
			p1.setPrice(detachedPOJO.getPrice());
			p1.setProdName(detachedPOJO.getProdName());
			return p1;
		}
		return null;
	}

	@Override
	public String deleteProduct(int productId) {
		proRepo.deleteById(productId);
		return "Product with ID="+productId+" deleted...";
	}

	
	
	

}
