package com.app.service;

import java.util.List;

import com.app.pojo.Employees;

public interface IEmployeeService {

	public List<Employees> getAllEmployee();
	public Employees addNewEmployee(Employees newEmployee);
	public String deteleteEmployeeById(int id);
}
