package com.app.service;

import java.util.Optional;
import org.springframework.http.ResponseEntity;
import com.app.pojo.Customers;

public interface ICustomerService {

	public ResponseEntity<?> getAllCustomers();
	
	public ResponseEntity<Customers> AddNewCustomer( Customers transientPOJO);
	
	public ResponseEntity<Customers> updateCustomerById(int id, Customers detachedPOJO);
	
	public Optional<Customers> getCustomerById(int id);
	
	public ResponseEntity<?> deleteAllCustomer();
	
	public ResponseEntity<?> deleteCustomerById(int id);
}
