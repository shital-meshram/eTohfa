package com.app.service;

import java.util.List;
import java.util.Optional;

import com.app.pojo.Products;

public interface IProductService {

	public List<Products> getAllProduct();
	Products AddNewProducts(Products transientPOJO);
	Optional<Products> getProductsById(int id);
	Products updateProductDetails(int productId, Products detachedPOJO);
	String deleteProduct(int productId);
}
