package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaProjectEtohfaSpringBootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaProjectEtohfaSpringBootRestApiApplication.class, args);
	}

}
