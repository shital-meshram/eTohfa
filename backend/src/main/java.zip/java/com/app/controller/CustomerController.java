package com.app.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.pojo.Address;
import com.app.pojo.Customers;
import com.app.service.IAddressService;
import com.app.service.ICustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private ICustomerService custService;
	
	@Autowired
	private IAddressService addService;
	
	
	@GetMapping("/getcustomer")
	public ResponseEntity<?> getAllCustomer()
	{
		return custService.getAllCustomers();
	}
	
	@PostMapping
	public ResponseEntity<Customers> addNewCustomer(@RequestBody Customers cust)
	{
		try {
			return custService.AddNewCustomer(cust);
		}catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@GetMapping("/getaddress")
	public List<Address> getAllAddress()
	{
		return addService.getAllAddress();
	}
	
	
	@PutMapping("/{customerId}")
	public ResponseEntity<Customers> updateCustomerDetails(@PathVariable int customerId, @RequestBody Customers cust)
	{
		try {
			return custService.updateCustomerById(customerId, cust);
		}catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/{id}")
	public Optional<Customers> getCustomerById(@PathVariable int id)
	{
		return custService.getCustomerById(id);
	}
	
	@DeleteMapping
	public ResponseEntity<?> deleteAllCustomers()
	{
		return custService.deleteAllCustomer();
	}
	
	
	@DeleteMapping("/{customerId}")
	public ResponseEntity<?> deleteCustomerById(@PathVariable int customerId)
	{
		return custService.deleteCustomerById(customerId);
	}
}








