package com.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojo.Products;
import com.app.service.IProductService;


@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired 
	private IProductService productService;
		
	@GetMapping
	public List<Products> getAllProducts()
	{
		return productService.getAllProduct();
	}
	
	@PostMapping
	public ResponseEntity<?> AddNewProduct(@RequestBody Products newProduct)
	{
		try {
			Products newProd = productService.AddNewProducts(newProduct);
			return new ResponseEntity<Products>(newProd, HttpStatus.OK);
		}
		catch (RuntimeException e) {
	      e.printStackTrace();
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/{productId}")
	public ResponseEntity<?> updatePProduct(@PathVariable int productId,@RequestBody Products p)
	{
		   try {
			   Products updateDetails=productService.updateProductDetails(productId, p);
			   return new ResponseEntity<>(updateDetails, HttpStatus.OK);
		   }
		   catch (RuntimeException e) {
				e.printStackTrace();
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
	}
	
	@DeleteMapping("/delete/{productId}")
	public String deleteProduct(@PathVariable int productId)
	{
		System.out.println("in del product "+productId);
        return productService.deleteProduct(productId);
	}
	
	@GetMapping("/{productId}")
	public ResponseEntity<?> getProductById(@PathVariable int productId)
	{
		  Optional<Products> product =productService.getProductsById(productId);
		  if(product.isPresent())
			  return new ResponseEntity<>(product,HttpStatus.OK);
		  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
}
