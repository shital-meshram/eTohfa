package com.app.pojo;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="categories")
public class Categories implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id")
	private Integer catId;
	@Column (length = 30, unique = true)
	private String CatName;
	@Column (length = 30)
	private String Brand;
	
	 public Categories() {
		// TODO Auto-generated constructor stub
		 System.out.println("category constr");
	}
	
	@OneToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL,mappedBy ="category")
	private List<Products> products=new ArrayList<Products>();
	
	public Integer getCatId() {
		return catId;
	}
	public void setCatId(Integer catId) {
		this.catId = catId;
	}
	public String getCatName() {
		return CatName;
	}
	public void setCatName(String catName) {
		CatName = catName;
	}
	public String getBrand() {
		return Brand;
	}
	public void setBrand(String brand) {
		Brand = brand;
	}
	
	public Categories(Integer catId, String catName, String brand) {
		super();
		this.catId = catId;
		CatName = catName;
		Brand = brand;
	}
	
	
	
	
}
